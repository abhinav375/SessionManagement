package com.cg.Training.controllers;
import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import org.apache.catalina.connector.Request;
import org.jboss.logging.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.Training.beans.Session;
import com.cg.Training.service.TrainingService;
@Controller
public class CustomerActionController
{      @Autowired
	TrainingService trainingService;

@RequestMapping(value="/")
public ModelAndView registerCustomer() throws Exception 
{
	
	List<Session>list=trainingService.showSession();
	ModelAndView mv=new ModelAndView();
	mv.setViewName("sessionsuccess");
	mv.addObject("list",list);
	return mv;
	
}
@RequestMapping(value="/enroll/{id}")  
public ModelAndView edit(@PathVariable String id){  
     Session s=trainingService.find(id);
     ModelAndView mv=new ModelAndView();
     mv.setViewName("success");
 	mv.addObject("user",s);
 	return mv;

}  	
}
