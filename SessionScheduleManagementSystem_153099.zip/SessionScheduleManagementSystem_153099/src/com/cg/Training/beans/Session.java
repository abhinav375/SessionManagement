package com.cg.Training.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="ScheduledSessions")
public class Session 
{
 
	@Id
	@NotEmpty
	String name;
	int Duration;
	@NotEmpty
	String faculty;
	@NotEmpty
	String mode1;
	
	
	public Session(String name, int duration, String faculty, String mode1) {
		super();
		this.name = name;
		Duration = duration;
		this.faculty = faculty;
		this.mode1 = mode1;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getDuration() {
		return Duration;
	}


	public void setDuration(int duration) {
		Duration = duration;
	}


	public String getFaculty() {
		return faculty;
	}


	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}


	public String getMode1() {
		return mode1;
	}


	public void setMode1(String mode1) {
		this.mode1 = mode1;
	}


	public Session() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	
	
	
	
}
