package com.cg.Training.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Training.beans.Session;

public interface TrainingDAO extends JpaRepository<Session, String>{

}
