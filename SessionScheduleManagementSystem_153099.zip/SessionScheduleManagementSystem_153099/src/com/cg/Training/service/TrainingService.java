package com.cg.Training.service;
import java.util.List;
import com.cg.Training.beans.*;
public interface TrainingService 
{

	Session find(String id);
	List<Session>showSession() throws Exception;
	
}
