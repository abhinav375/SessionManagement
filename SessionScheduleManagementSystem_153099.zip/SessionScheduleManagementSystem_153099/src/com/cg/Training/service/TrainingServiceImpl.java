package com.cg.Training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.Training.beans.Session;
import com.cg.Training.repo.TrainingDAO;
@Component(value="trainingService")
public class TrainingServiceImpl implements TrainingService {
	     @Autowired
          TrainingDAO dao;
	@Override
	public List<Session> showSession() throws Exception 
	{
		
		return(dao.findAll());
	}
	@Override
	public Session find(String id) {
		// 
		Session session=dao.findOne(id);
		return session;
	}

}
